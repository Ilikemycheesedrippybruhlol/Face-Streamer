import { useFaceDetection } from '@/hooks/useFaceDetection';
import VideoCanvas from '@/components/VideoCanvas';
import StatusBar from '@/components/StatusBar';
import ControlPanel from '@/components/ControlPanel';
import FaceDataPanel from '@/components/FaceDataPanel';
import ThemeToggle from '@/components/ThemeToggle';
import { Scan } from 'lucide-react';

export default function FaceTracker() {
  const {
    videoRef,
    canvasRef,
    isLoading,
    isRunning,
    error,
    fps,
    faceDetected,
    handsDetected,
    faceData,
    handsData,
    settings,
    startCamera,
    stopCamera,
    updateSettings,
  } = useFaceDetection();

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-14 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Scan className="w-6 h-6 text-primary" />
            <h1 className="text-lg font-semibold" data-testid="text-app-title">FaceTrack</h1>
          </div>
          <div className="flex items-center gap-4">
            <StatusBar 
              isRunning={isRunning} 
              faceDetected={faceDetected} 
              handsDetected={handsDetected}
              fps={fps} 
            />
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1 min-w-0">
            <VideoCanvas
              videoRef={videoRef}
              canvasRef={canvasRef}
              isLoading={isLoading}
              isRunning={isRunning}
              error={error}
            />
          </div>
          
          <aside className="w-full lg:w-80 flex-shrink-0">
            <div className="lg:max-h-[calc(100vh-8rem)] lg:overflow-y-auto space-y-4 pr-1">
              <ControlPanel
                isLoading={isLoading}
                isRunning={isRunning}
                settings={settings}
                onStartCamera={startCamera}
                onStopCamera={stopCamera}
                onUpdateSettings={updateSettings}
              />
              <FaceDataPanel 
                faceData={faceData} 
                handsData={handsData}
                faceDetected={faceDetected} 
                handsDetected={handsDetected}
              />
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
}
