import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Video, VideoOff, Square, Circle, Grid3X3, Eye, Camera, Hand, Spline, CircleDot } from 'lucide-react';
import type { TrackingSettings } from '@/hooks/useFaceDetection';

interface ControlPanelProps {
  isLoading: boolean;
  isRunning: boolean;
  settings: TrackingSettings;
  onStartCamera: () => void;
  onStopCamera: () => void;
  onUpdateSettings: (settings: Partial<TrackingSettings>) => void;
}

export default function ControlPanel({
  isLoading,
  isRunning,
  settings,
  onStartCamera,
  onStopCamera,
  onUpdateSettings,
}: ControlPanelProps) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Camera className="w-4 h-4" />
            Camera Controls
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isRunning ? (
            <Button 
              variant="destructive" 
              className="w-full gap-2"
              onClick={onStopCamera}
              data-testid="button-stop-camera"
            >
              <VideoOff className="w-4 h-4" />
              Stop Camera
            </Button>
          ) : (
            <Button 
              className="w-full gap-2"
              onClick={onStartCamera}
              disabled={isLoading}
              data-testid="button-start-camera"
            >
              <Video className="w-4 h-4" />
              {isLoading ? 'Loading Models...' : 'Start Camera'}
            </Button>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Face Tracking
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Square className="w-4 h-4 text-muted-foreground" />
              <Label htmlFor="show-box" className="text-sm cursor-pointer">
                Bounding Box
              </Label>
            </div>
            <Switch
              id="show-box"
              checked={settings.showBoundingBox}
              onCheckedChange={(checked) => onUpdateSettings({ showBoundingBox: checked })}
              data-testid="switch-bounding-box"
            />
          </div>

          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Circle className="w-4 h-4 text-muted-foreground" />
              <Label htmlFor="show-landmarks" className="text-sm cursor-pointer">
                Key Landmarks
              </Label>
            </div>
            <Switch
              id="show-landmarks"
              checked={settings.showLandmarks}
              onCheckedChange={(checked) => onUpdateSettings({ showLandmarks: checked })}
              data-testid="switch-landmarks"
            />
          </div>

          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <CircleDot className="w-4 h-4 text-muted-foreground" />
              <Label htmlFor="show-all-landmarks" className="text-sm cursor-pointer">
                All 468 Points
              </Label>
            </div>
            <Switch
              id="show-all-landmarks"
              checked={settings.showAllLandmarks}
              onCheckedChange={(checked) => onUpdateSettings({ showAllLandmarks: checked })}
              data-testid="switch-all-landmarks"
            />
          </div>

          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Spline className="w-4 h-4 text-muted-foreground" />
              <Label htmlFor="show-contours" className="text-sm cursor-pointer">
                Face Contours
              </Label>
            </div>
            <Switch
              id="show-contours"
              checked={settings.showContours}
              onCheckedChange={(checked) => onUpdateSettings({ showContours: checked })}
              data-testid="switch-contours"
            />
          </div>

          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Grid3X3 className="w-4 h-4 text-muted-foreground" />
              <Label htmlFor="show-mesh" className="text-sm cursor-pointer">
                Face Mesh
              </Label>
            </div>
            <Switch
              id="show-mesh"
              checked={settings.showMesh}
              onCheckedChange={(checked) => onUpdateSettings({ showMesh: checked })}
              data-testid="switch-mesh"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Hand className="w-4 h-4" />
            Hand Tracking
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Circle className="w-4 h-4 text-muted-foreground" />
              <Label htmlFor="show-hands" className="text-sm cursor-pointer">
                Hand Points
              </Label>
            </div>
            <Switch
              id="show-hands"
              checked={settings.showHands}
              onCheckedChange={(checked) => onUpdateSettings({ showHands: checked })}
              data-testid="switch-hands"
            />
          </div>

          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Spline className="w-4 h-4 text-muted-foreground" />
              <Label htmlFor="show-hand-skeleton" className="text-sm cursor-pointer">
                Hand Skeleton
              </Label>
            </div>
            <Switch
              id="show-hand-skeleton"
              checked={settings.showHandSkeleton}
              onCheckedChange={(checked) => onUpdateSettings({ showHandSkeleton: checked })}
              data-testid="switch-hand-skeleton"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Display Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-4">
              <Label className="text-sm">Overlay Opacity</Label>
              <span className="text-xs text-muted-foreground font-mono">
                {Math.round(settings.overlayOpacity * 100)}%
              </span>
            </div>
            <Slider
              value={[settings.overlayOpacity]}
              onValueChange={([value]) => onUpdateSettings({ overlayOpacity: value })}
              min={0.1}
              max={1}
              step={0.1}
              data-testid="slider-opacity"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between gap-4">
              <Label className="text-sm">Landmark Size</Label>
              <span className="text-xs text-muted-foreground font-mono">
                {settings.landmarkSize}px
              </span>
            </div>
            <Slider
              value={[settings.landmarkSize]}
              onValueChange={([value]) => onUpdateSettings({ landmarkSize: value })}
              min={1}
              max={6}
              step={1}
              data-testid="slider-landmark-size"
            />
          </div>

          <Separator />

          <div className="space-y-3">
            <Label className="text-sm">Colors</Label>
            
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-muted-foreground">Box</span>
                <input
                  type="color"
                  value={settings.boundingBoxColor}
                  onChange={(e) => onUpdateSettings({ boundingBoxColor: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer border border-border"
                  data-testid="input-color-box"
                />
              </div>
              
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-muted-foreground">Points</span>
                <input
                  type="color"
                  value={settings.landmarkColor}
                  onChange={(e) => onUpdateSettings({ landmarkColor: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer border border-border"
                  data-testid="input-color-landmarks"
                />
              </div>
              
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-muted-foreground">Contours</span>
                <input
                  type="color"
                  value={settings.contourColor}
                  onChange={(e) => onUpdateSettings({ contourColor: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer border border-border"
                  data-testid="input-color-contours"
                />
              </div>
              
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-muted-foreground">Mesh</span>
                <input
                  type="color"
                  value={settings.meshColor}
                  onChange={(e) => onUpdateSettings({ meshColor: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer border border-border"
                  data-testid="input-color-mesh"
                />
              </div>

              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-muted-foreground">Left Hand</span>
                <input
                  type="color"
                  value={settings.leftHandColor}
                  onChange={(e) => onUpdateSettings({ leftHandColor: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer border border-border"
                  data-testid="input-color-left-hand"
                />
              </div>

              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-muted-foreground">Right Hand</span>
                <input
                  type="color"
                  value={settings.rightHandColor}
                  onChange={(e) => onUpdateSettings({ rightHandColor: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer border border-border"
                  data-testid="input-color-right-hand"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
