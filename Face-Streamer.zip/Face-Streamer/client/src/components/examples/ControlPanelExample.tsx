import { useState } from 'react';
import ControlPanel from '../ControlPanel';
import type { TrackingSettings } from '@/hooks/useFaceDetection';

export default function ControlPanelExample() {
  const [settings, setSettings] = useState<TrackingSettings>({
    showBoundingBox: true,
    showLandmarks: true,
    showAllLandmarks: false,
    showMesh: false,
    showContours: true,
    showHands: true,
    showHandSkeleton: true,
    overlayOpacity: 0.9,
    landmarkSize: 2,
    boundingBoxColor: '#00ff00',
    landmarkColor: '#ff3366',
    meshColor: '#0088ff',
    contourColor: '#ffcc00',
    leftHandColor: '#ff6600',
    rightHandColor: '#00ccff',
  });

  return (
    <div className="w-72">
      <ControlPanel
        isLoading={false}
        isRunning={false}
        settings={settings}
        onStartCamera={() => console.log('Start camera clicked')}
        onStopCamera={() => console.log('Stop camera clicked')}
        onUpdateSettings={(newSettings) => setSettings(prev => ({ ...prev, ...newSettings }))}
      />
    </div>
  );
}
