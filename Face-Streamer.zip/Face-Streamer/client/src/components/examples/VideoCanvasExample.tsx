import { useRef } from 'react';
import VideoCanvas from '../VideoCanvas';

export default function VideoCanvasExample() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  return (
    <div className="w-full max-w-2xl">
      <VideoCanvas
        videoRef={videoRef}
        canvasRef={canvasRef}
        isLoading={false}
        isRunning={false}
        error={null}
      />
    </div>
  );
}
