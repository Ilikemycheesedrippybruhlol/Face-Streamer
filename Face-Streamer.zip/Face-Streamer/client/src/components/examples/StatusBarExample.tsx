import StatusBar from '../StatusBar';

export default function StatusBarExample() {
  return (
    <div className="p-4">
      <StatusBar isRunning={true} faceDetected={true} handsDetected={2} fps={30} />
    </div>
  );
}
