import { RefObject } from 'react';
import { Card } from '@/components/ui/card';
import { Loader2, VideoOff } from 'lucide-react';

interface VideoCanvasProps {
  videoRef: RefObject<HTMLVideoElement>;
  canvasRef: RefObject<HTMLCanvasElement>;
  isLoading: boolean;
  isRunning: boolean;
  error: string | null;
}

export default function VideoCanvas({ 
  videoRef, 
  canvasRef, 
  isLoading, 
  isRunning, 
  error 
}: VideoCanvasProps) {
  return (
    <Card className="relative overflow-hidden bg-black aspect-video w-full">
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-cover"
        playsInline
        muted
        data-testid="video-feed"
      />
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full object-cover pointer-events-none"
        data-testid="canvas-overlay"
      />
      
      {!isRunning && !isLoading && !error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted/80">
          <VideoOff className="w-16 h-16 text-muted-foreground mb-4" />
          <p className="text-muted-foreground text-sm font-medium" data-testid="text-camera-off">
            Camera is off
          </p>
          <p className="text-muted-foreground/70 text-xs mt-1">
            Click "Start Camera" to begin
          </p>
        </div>
      )}
      
      {isLoading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted/80">
          <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
          <p className="text-muted-foreground text-sm font-medium" data-testid="text-loading">
            Loading face detection model...
          </p>
        </div>
      )}
      
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-destructive/10">
          <VideoOff className="w-16 h-16 text-destructive mb-4" />
          <p className="text-destructive text-sm font-medium text-center px-4" data-testid="text-error">
            {error}
          </p>
        </div>
      )}
    </Card>
  );
}
