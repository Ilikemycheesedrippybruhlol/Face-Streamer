import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity, Hand } from 'lucide-react';
import type { FaceData, HandData } from '@/hooks/useFaceDetection';

interface FaceDataPanelProps {
  faceData: FaceData | null;
  handsData: HandData[];
  faceDetected: boolean;
  handsDetected: number;
}

export default function FaceDataPanel({ faceData, handsData, faceDetected, handsDetected }: FaceDataPanelProps) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Face Data
          </CardTitle>
        </CardHeader>
        <CardContent>
          {faceDetected && faceData ? (
            <div className="space-y-2 font-mono text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-muted rounded p-2">
                  <span className="text-muted-foreground block">X</span>
                  <span data-testid="text-pos-x">{Math.round(faceData.box.xMin)}</span>
                </div>
                <div className="bg-muted rounded p-2">
                  <span className="text-muted-foreground block">Y</span>
                  <span data-testid="text-pos-y">{Math.round(faceData.box.yMin)}</span>
                </div>
                <div className="bg-muted rounded p-2">
                  <span className="text-muted-foreground block">W</span>
                  <span data-testid="text-width">{Math.round(faceData.box.width)}</span>
                </div>
                <div className="bg-muted rounded p-2">
                  <span className="text-muted-foreground block">H</span>
                  <span data-testid="text-height">{Math.round(faceData.box.height)}</span>
                </div>
              </div>
              <div className="bg-muted rounded p-2">
                <span className="text-muted-foreground block">Landmarks</span>
                <span data-testid="text-landmarks-count">{faceData.keypoints.length} points</span>
              </div>
            </div>
          ) : (
            <p className="text-muted-foreground text-sm text-center py-2" data-testid="text-no-face-data">
              No face detected
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Hand className="w-4 h-4" />
            Hand Data
          </CardTitle>
        </CardHeader>
        <CardContent>
          {handsDetected > 0 && handsData.length > 0 ? (
            <div className="space-y-3">
              {handsData.map((hand, idx) => (
                <div key={idx} className="space-y-2 font-mono text-xs">
                  <div className="flex items-center gap-2">
                    <span 
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: hand.handedness === 'Left' ? '#ff6600' : '#00ccff' }}
                    />
                    <span className="font-semibold" data-testid={`text-hand-${idx}`}>
                      {hand.handedness} Hand
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-muted rounded p-2">
                      <span className="text-muted-foreground block">Points</span>
                      <span>{hand.keypoints.length}</span>
                    </div>
                    <div className="bg-muted rounded p-2">
                      <span className="text-muted-foreground block">Wrist</span>
                      <span>
                        {Math.round(hand.keypoints[0]?.x || 0)}, {Math.round(hand.keypoints[0]?.y || 0)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-sm text-center py-2" data-testid="text-no-hand-data">
              No hands detected
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
