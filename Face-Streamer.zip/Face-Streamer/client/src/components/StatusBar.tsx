import { Badge } from '@/components/ui/badge';
import { Video, VideoOff, User, UserX, Hand } from 'lucide-react';

interface StatusBarProps {
  isRunning: boolean;
  faceDetected: boolean;
  handsDetected: number;
  fps: number;
}

export default function StatusBar({ isRunning, faceDetected, handsDetected, fps }: StatusBarProps) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Badge 
        variant={isRunning ? "default" : "secondary"}
        className="gap-1.5"
        data-testid="status-camera"
      >
        {isRunning ? (
          <>
            <Video className="w-3 h-3" />
            Live
          </>
        ) : (
          <>
            <VideoOff className="w-3 h-3" />
            Off
          </>
        )}
      </Badge>
      
      <Badge 
        variant={faceDetected ? "default" : "secondary"}
        className="gap-1.5"
        data-testid="status-face"
      >
        {faceDetected ? (
          <>
            <User className="w-3 h-3" />
            Face
          </>
        ) : (
          <>
            <UserX className="w-3 h-3" />
            No Face
          </>
        )}
      </Badge>

      <Badge 
        variant={handsDetected > 0 ? "default" : "secondary"}
        className="gap-1.5"
        data-testid="status-hands"
      >
        <Hand className="w-3 h-3" />
        {handsDetected} Hand{handsDetected !== 1 ? 's' : ''}
      </Badge>
      
      <Badge variant="outline" className="font-mono" data-testid="status-fps">
        {fps} FPS
      </Badge>
    </div>
  );
}
