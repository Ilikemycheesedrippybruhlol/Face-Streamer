import { useRef, useState, useCallback, useEffect } from 'react';
import * as tf from '@tensorflow/tfjs';
import * as faceLandmarksDetection from '@tensorflow-models/face-landmarks-detection';
import * as handPoseDetection from '@tensorflow-models/hand-pose-detection';
import * as poseDetection from '@tensorflow-models/pose-detection';

export interface FaceData {
  box: {
    xMin: number;
    yMin: number;
    xMax: number;
    yMax: number;
    width: number;
    height: number;
  };
  keypoints: Array<{
    x: number;
    y: number;
    z?: number;
    name?: string;
  }>;
}

export interface HandData {
  handedness: string;
  keypoints: Array<{
    x: number;
    y: number;
    z?: number;
    name?: string;
  }>;
}

export interface PoseData {
  keypoints: Array<{
    x: number;
    y: number;
    z?: number;
    score?: number;
    name?: string;
  }>;
}

export interface TrackingSettings {
  showBoundingBox: boolean;
  showLandmarks: boolean;
  showAllLandmarks: boolean;
  showMesh: boolean;
  showContours: boolean;
  showHands: boolean;
  showHandSkeleton: boolean;
  showBody: boolean;
  showBodySkeleton: boolean;
  showBodyPoints: boolean;
  overlayOpacity: number;
  landmarkSize: number;
  boundingBoxColor: string;
  landmarkColor: string;
  meshColor: string;
  contourColor: string;
  leftHandColor: string;
  rightHandColor: string;
  bodyColor: string;
  armColor: string;
  legColor: string;
  torsoColor: string;
}

const FACE_CONTOURS = {
  lips: [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185, 61],
  leftEye: [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246, 33],
  rightEye: [362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398, 362],
  leftEyebrow: [70, 63, 105, 66, 107, 55, 65, 52, 53, 46],
  rightEyebrow: [300, 293, 334, 296, 336, 285, 295, 282, 283, 276],
  faceOval: [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109, 10],
  nose: [168, 6, 197, 195, 5, 4, 1, 19, 94, 2],
};

const HAND_CONNECTIONS = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [0, 9], [9, 10], [10, 11], [11, 12],
  [0, 13], [13, 14], [14, 15], [15, 16],
  [0, 17], [17, 18], [18, 19], [19, 20],
  [5, 9], [9, 13], [13, 17],
];

const POSE_CONNECTIONS = {
  face: [
    [0, 1], [1, 2], [2, 3], [3, 7],
    [0, 4], [4, 5], [5, 6], [6, 8],
    [9, 10],
  ],
  arms: [
    [11, 13], [13, 15],
    [15, 17], [15, 19], [15, 21], [17, 19],
    [12, 14], [14, 16],
    [16, 18], [16, 20], [16, 22], [18, 20],
  ],
  torso: [
    [11, 12],
    [11, 23], [12, 24],
    [23, 24],
  ],
  legs: [
    [23, 25], [25, 27], [27, 29], [27, 31], [29, 31],
    [24, 26], [26, 28], [28, 30], [28, 32], [30, 32],
  ],
};

const POSE_KEYPOINT_NAMES = [
  'nose', 'left_eye_inner', 'left_eye', 'left_eye_outer',
  'right_eye_inner', 'right_eye', 'right_eye_outer',
  'left_ear', 'right_ear', 'mouth_left', 'mouth_right',
  'left_shoulder', 'right_shoulder', 'left_elbow', 'right_elbow',
  'left_wrist', 'right_wrist', 'left_pinky', 'right_pinky',
  'left_index', 'right_index', 'left_thumb', 'right_thumb',
  'left_hip', 'right_hip', 'left_knee', 'right_knee',
  'left_ankle', 'right_ankle', 'left_heel', 'right_heel',
  'left_foot_index', 'right_foot_index',
];

export function useFaceDetection() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const faceDetectorRef = useRef<faceLandmarksDetection.FaceLandmarksDetector | null>(null);
  const handDetectorRef = useRef<handPoseDetection.HandDetector | null>(null);
  const poseDetectorRef = useRef<poseDetection.PoseDetector | null>(null);
  const animationRef = useRef<number | null>(null);
  
  const [isLoading, setIsLoading] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fps, setFps] = useState(0);
  const [faceDetected, setFaceDetected] = useState(false);
  const [handsDetected, setHandsDetected] = useState(0);
  const [bodyDetected, setBodyDetected] = useState(false);
  const [faceData, setFaceData] = useState<FaceData | null>(null);
  const [handsData, setHandsData] = useState<HandData[]>([]);
  const [poseData, setPoseData] = useState<PoseData | null>(null);
  
  const lastTimeRef = useRef<number>(performance.now());
  const frameCountRef = useRef<number>(0);

  const [settings, setSettings] = useState<TrackingSettings>({
    showBoundingBox: true,
    showLandmarks: true,
    showAllLandmarks: false,
    showMesh: false,
    showContours: true,
    showHands: true,
    showHandSkeleton: true,
    showBody: true,
    showBodySkeleton: true,
    showBodyPoints: true,
    overlayOpacity: 0.9,
    landmarkSize: 2,
    boundingBoxColor: '#00ff00',
    landmarkColor: '#ff3366',
    meshColor: '#0088ff',
    contourColor: '#ffcc00',
    leftHandColor: '#ff6600',
    rightHandColor: '#00ccff',
    bodyColor: '#00ff88',
    armColor: '#ff44aa',
    legColor: '#44aaff',
    torsoColor: '#ffaa00',
  });

  const initializeDetectors = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      await tf.setBackend('webgl');
      await tf.ready();
      
      const faceModel = faceLandmarksDetection.SupportedModels.MediaPipeFaceMesh;
      const faceConfig: faceLandmarksDetection.MediaPipeFaceMeshMediaPipeModelConfig = {
        runtime: 'mediapipe',
        solutionPath: 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh',
        refineLandmarks: true,
        maxFaces: 1,
      };
      
      faceDetectorRef.current = await faceLandmarksDetection.createDetector(faceModel, faceConfig);
      
      const handModel = handPoseDetection.SupportedModels.MediaPipeHands;
      const handConfig: handPoseDetection.MediaPipeHandsMediaPipeModelConfig = {
        runtime: 'mediapipe',
        solutionPath: 'https://cdn.jsdelivr.net/npm/@mediapipe/hands',
        modelType: 'full',
        maxHands: 2,
      };
      
      handDetectorRef.current = await handPoseDetection.createDetector(handModel, handConfig);

      const poseModel = poseDetection.SupportedModels.BlazePose;
      const poseConfig: poseDetection.BlazePoseMediaPipeModelConfig = {
        runtime: 'mediapipe',
        solutionPath: 'https://cdn.jsdelivr.net/npm/@mediapipe/pose',
        modelType: 'full',
        enableSmoothing: true,
      };
      
      poseDetectorRef.current = await poseDetection.createDetector(poseModel, poseConfig);
      
      setIsLoading(false);
    } catch (err) {
      setError('Failed to initialize detection models');
      setIsLoading(false);
      console.error(err);
    }
  }, []);

  const startCamera = useCallback(async () => {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 1280, height: 720 },
        audio: false,
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      
      if (!faceDetectorRef.current || !handDetectorRef.current || !poseDetectorRef.current) {
        await initializeDetectors();
      }
      
      setIsRunning(true);
    } catch (err) {
      setError('Failed to access camera. Please ensure camera permissions are granted.');
      console.error(err);
    }
  }, [initializeDetectors]);

  const stopCamera = useCallback(() => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    }
    
    setIsRunning(false);
    setFaceDetected(false);
    setHandsDetected(0);
    setBodyDetected(false);
    setFaceData(null);
    setHandsData([]);
    setPoseData(null);
    setFps(0);
  }, []);

  const drawFaceOverlays = useCallback((ctx: CanvasRenderingContext2D, faces: faceLandmarksDetection.Face[]) => {
    if (faces.length === 0) {
      setFaceDetected(false);
      setFaceData(null);
      return;
    }

    const face = faces[0];
    setFaceDetected(true);
    
    const keypoints = face.keypoints;
    const xCoords = keypoints.map(kp => kp.x);
    const yCoords = keypoints.map(kp => kp.y);
    const xMin = Math.min(...xCoords);
    const xMax = Math.max(...xCoords);
    const yMin = Math.min(...yCoords);
    const yMax = Math.max(...yCoords);
    
    setFaceData({
      box: { xMin, yMin, xMax, yMax, width: xMax - xMin, height: yMax - yMin },
      keypoints: keypoints,
    });

    if (settings.showBoundingBox) {
      ctx.strokeStyle = settings.boundingBoxColor;
      ctx.lineWidth = 2;
      ctx.strokeRect(xMin - 10, yMin - 10, xMax - xMin + 20, yMax - yMin + 20);
      
      ctx.fillStyle = settings.boundingBoxColor;
      ctx.font = 'bold 12px monospace';
      ctx.fillText('FACE', xMin - 10, yMin - 15);
    }

    if (settings.showMesh) {
      ctx.strokeStyle = settings.meshColor;
      ctx.lineWidth = 0.3;
      
      const TRIANGULATION = [
        127, 34, 139, 11, 0, 37, 232, 231, 120, 72, 37, 39, 128, 121, 47,
        232, 121, 128, 104, 69, 67, 175, 171, 148, 157, 154, 155, 118, 50,
        101, 73, 39, 40, 9, 151, 108, 48, 115, 131, 194, 204, 211, 74, 40,
        185, 80, 42, 183, 40, 92, 186, 230, 229, 118, 202, 212, 214, 83,
      ];

      for (let i = 0; i < TRIANGULATION.length; i += 3) {
        const p1 = keypoints[TRIANGULATION[i]];
        const p2 = keypoints[TRIANGULATION[i + 1]];
        const p3 = keypoints[TRIANGULATION[i + 2]];
        
        if (p1 && p2 && p3) {
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.lineTo(p3.x, p3.y);
          ctx.closePath();
          ctx.stroke();
        }
      }
    }

    if (settings.showContours) {
      ctx.strokeStyle = settings.contourColor;
      ctx.lineWidth = 2;
      
      Object.values(FACE_CONTOURS).forEach(contour => {
        ctx.beginPath();
        for (let i = 0; i < contour.length; i++) {
          const kp = keypoints[contour[i]];
          if (kp) {
            if (i === 0) {
              ctx.moveTo(kp.x, kp.y);
            } else {
              ctx.lineTo(kp.x, kp.y);
            }
          }
        }
        ctx.stroke();
      });
    }

    if (settings.showAllLandmarks) {
      ctx.fillStyle = settings.landmarkColor;
      keypoints.forEach(kp => {
        ctx.beginPath();
        ctx.arc(kp.x, kp.y, settings.landmarkSize, 0, 2 * Math.PI);
        ctx.fill();
      });
    } else if (settings.showLandmarks) {
      ctx.fillStyle = settings.landmarkColor;
      
      const importantPoints = [
        33, 133, 362, 263, 1, 2, 98, 327, 61, 291, 0, 17, 78, 308, 14, 13,
        70, 63, 105, 66, 107, 336, 296, 334, 293, 300, 168, 6, 197, 195, 5,
      ];
      
      importantPoints.forEach(idx => {
        const kp = keypoints[idx];
        if (kp) {
          ctx.beginPath();
          ctx.arc(kp.x, kp.y, settings.landmarkSize + 1, 0, 2 * Math.PI);
          ctx.fill();
        }
      });
    }
  }, [settings]);

  const drawHandOverlays = useCallback((ctx: CanvasRenderingContext2D, hands: handPoseDetection.Hand[]) => {
    setHandsDetected(hands.length);
    
    if (hands.length === 0) {
      setHandsData([]);
      return;
    }

    const newHandsData: HandData[] = [];

    hands.forEach(hand => {
      const color = hand.handedness === 'Left' ? settings.leftHandColor : settings.rightHandColor;
      const keypoints = hand.keypoints;
      
      newHandsData.push({
        handedness: hand.handedness,
        keypoints: keypoints,
      });

      if (settings.showHandSkeleton) {
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        
        HAND_CONNECTIONS.forEach(([start, end]) => {
          const p1 = keypoints[start];
          const p2 = keypoints[end];
          if (p1 && p2) {
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        });
      }

      if (settings.showHands) {
        keypoints.forEach((kp, idx) => {
          ctx.beginPath();
          const size = idx === 0 ? 6 : (idx % 4 === 0 ? 5 : 3);
          ctx.arc(kp.x, kp.y, size, 0, 2 * Math.PI);
          ctx.fillStyle = color;
          ctx.fill();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1;
          ctx.stroke();
        });
      }
    });

    setHandsData(newHandsData);
  }, [settings]);

  const drawPoseOverlays = useCallback((ctx: CanvasRenderingContext2D, poses: poseDetection.Pose[]) => {
    if (poses.length === 0) {
      setBodyDetected(false);
      setPoseData(null);
      return;
    }

    const pose = poses[0];
    const keypoints = pose.keypoints;
    
    const visibleKeypoints = keypoints.filter(kp => (kp.score || 0) > 0.3);
    setBodyDetected(visibleKeypoints.length > 10);
    
    setPoseData({
      keypoints: keypoints.map((kp, idx) => ({
        ...kp,
        name: POSE_KEYPOINT_NAMES[idx],
      })),
    });

    if (!settings.showBody) return;

    const drawConnection = (connections: number[][], color: string, lineWidth: number = 4) => {
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth;
      
      connections.forEach(([start, end]) => {
        const p1 = keypoints[start];
        const p2 = keypoints[end];
        if (p1 && p2 && (p1.score || 0) > 0.3 && (p2.score || 0) > 0.3) {
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
        }
      });
    };

    if (settings.showBodySkeleton) {
      drawConnection(POSE_CONNECTIONS.torso, settings.torsoColor, 5);
      drawConnection(POSE_CONNECTIONS.arms, settings.armColor, 4);
      drawConnection(POSE_CONNECTIONS.legs, settings.legColor, 4);
    }

    if (settings.showBodyPoints) {
      keypoints.forEach((kp, idx) => {
        if ((kp.score || 0) > 0.3) {
          let color = settings.bodyColor;
          let size = 5;
          
          if (idx >= 11 && idx <= 22) {
            color = settings.armColor;
            size = 6;
          } else if (idx >= 23 && idx <= 32) {
            color = settings.legColor;
            size = 6;
          } else if (idx >= 11 && idx <= 12 || idx >= 23 && idx <= 24) {
            color = settings.torsoColor;
            size = 8;
          }

          ctx.beginPath();
          ctx.arc(kp.x, kp.y, size, 0, 2 * Math.PI);
          ctx.fillStyle = color;
          ctx.fill();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      });

      const leftShoulder = keypoints[11];
      const rightShoulder = keypoints[12];
      const leftHip = keypoints[23];
      const rightHip = keypoints[24];
      
      if (leftShoulder && rightShoulder && leftHip && rightHip &&
          (leftShoulder.score || 0) > 0.3 && (rightShoulder.score || 0) > 0.3 &&
          (leftHip.score || 0) > 0.3 && (rightHip.score || 0) > 0.3) {
        const centerX = (leftShoulder.x + rightShoulder.x + leftHip.x + rightHip.x) / 4;
        const centerY = (leftShoulder.y + rightShoulder.y + leftHip.y + rightHip.y) / 4;
        
        ctx.beginPath();
        ctx.arc(centerX, centerY, 10, 0, 2 * Math.PI);
        ctx.fillStyle = settings.torsoColor;
        ctx.globalAlpha = 0.6;
        ctx.fill();
        ctx.globalAlpha = settings.overlayOpacity;
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        ctx.fillStyle = settings.torsoColor;
        ctx.font = 'bold 10px monospace';
        ctx.fillText('TORSO', centerX - 18, centerY - 15);
      }
    }
  }, [settings]);

  const detect = useCallback(async () => {
    if (!isRunning || !videoRef.current) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    if (video.readyState !== 4 || !canvas) {
      animationRef.current = requestAnimationFrame(detect);
      return;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      animationRef.current = requestAnimationFrame(detect);
      return;
    }

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.globalAlpha = settings.overlayOpacity;

    try {
      const [faces, hands, poses] = await Promise.all([
        faceDetectorRef.current?.estimateFaces(video, { flipHorizontal: false }) ?? [],
        handDetectorRef.current?.estimateHands(video, { flipHorizontal: false }) ?? [],
        poseDetectorRef.current?.estimatePoses(video, { flipHorizontal: false }) ?? [],
      ]);

      drawPoseOverlays(ctx, poses);
      drawHandOverlays(ctx, hands);
      drawFaceOverlays(ctx, faces);
      
      frameCountRef.current++;
      const now = performance.now();
      const elapsed = now - lastTimeRef.current;
      
      if (elapsed >= 1000) {
        setFps(Math.round((frameCountRef.current * 1000) / elapsed));
        frameCountRef.current = 0;
        lastTimeRef.current = now;
      }
    } catch (err) {
      console.error('Detection error:', err);
    }
    
    animationRef.current = requestAnimationFrame(detect);
  }, [isRunning, settings.overlayOpacity, drawFaceOverlays, drawHandOverlays, drawPoseOverlays]);

  useEffect(() => {
    if (isRunning) {
      animationRef.current = requestAnimationFrame(detect);
    }
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isRunning, detect]);

  useEffect(() => {
    return () => {
      stopCamera();
      faceDetectorRef.current = null;
      handDetectorRef.current = null;
      poseDetectorRef.current = null;
    };
  }, [stopCamera]);

  const updateSettings = useCallback((newSettings: Partial<TrackingSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  }, []);

  return {
    videoRef,
    canvasRef,
    isLoading,
    isRunning,
    error,
    fps,
    faceDetected,
    handsDetected,
    bodyDetected,
    faceData,
    handsData,
    poseData,
    settings,
    startCamera,
    stopCamera,
    updateSettings,
  };
}
