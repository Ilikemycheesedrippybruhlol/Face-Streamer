import FaceDataPanel from '../FaceDataPanel';

export default function FaceDataPanelExample() {
  const mockFaceData = {
    box: {
      xMin: 320,
      yMin: 180,
      xMax: 560,
      yMax: 480,
      width: 240,
      height: 300,
    },
    keypoints: new Array(478).fill({ x: 0, y: 0 }),
  };

  const mockHandsData = [
    {
      handedness: 'Left',
      keypoints: new Array(21).fill({ x: 100, y: 200 }),
    },
    {
      handedness: 'Right',
      keypoints: new Array(21).fill({ x: 400, y: 200 }),
    },
  ];

  return (
    <div className="w-72">
      <FaceDataPanel 
        faceData={mockFaceData} 
        handsData={mockHandsData}
        faceDetected={true} 
        handsDetected={2}
      />
    </div>
  );
}
