# Face Tracker Application - Design Guidelines

## Design Approach
**System**: Material Design adapted for video production tools
**Rationale**: Utility-focused application requiring clear controls, real-time feedback, and professional interface common in streaming/recording software like OBS.

## Core Design Principles
1. **Video-First Layout**: Webcam feed dominates the viewport
2. **Control Accessibility**: Essential controls always visible and within reach
3. **Visual Clarity**: Clear distinction between video content and UI controls
4. **Real-time Feedback**: Immediate visual response to tracking and controls

## Layout System

### Grid Structure
- Single-page application layout
- Primary video area: 70-75% of viewport width (desktop)
- Control panel: 25-30% of viewport (right sidebar on desktop, bottom panel on mobile)
- Responsive breakpoints: stack vertically on tablet/mobile (video top, controls below)

### Spacing Primitives
Use Tailwind spacing units: **2, 4, 6, 8, 16**
- Component padding: `p-4` to `p-6`
- Section gaps: `gap-4` to `gap-6`
- Major spacing: `p-8` or `p-16`
- Tight elements: `gap-2`

## Typography

### Font Family
- Primary: **Inter** or **Roboto** (Google Fonts)
- Monospace: **Roboto Mono** for technical readouts (FPS, tracking data)

### Type Scale
- Section Headers: `text-lg font-semibold` (controls panel)
- Body/Labels: `text-sm font-medium`
- Technical Data: `text-xs font-mono`
- Button Text: `text-sm font-medium`

## Component Library

### Video Canvas Area
- Full-width container with aspect ratio preservation (16:9 or 4:3)
- Rounded corners: `rounded-lg`
- Video element fills container completely
- Face tracking overlays rendered on HTML canvas positioned absolutely over video

### Control Panel (Sidebar/Bottom Panel)
**Structure**: Organized into collapsible sections
- **Camera Controls**: Camera selection dropdown, resolution options
- **Tracking Options**: Toggle switches for face box, landmarks, mesh
- **Display Settings**: Overlay opacity slider, landmark style selector
- **Recording Status**: Connection status indicator, FPS counter

### Toggle Switches
- Material Design style toggle switches
- Each with clear label and current state
- Examples: "Show Face Box", "Show Landmarks", "Show Face Mesh"
- Grouped with consistent `gap-3` spacing

### Status Bar
Fixed position (top or within control panel):
- Camera status indicator (active/inactive)
- FPS counter (monospace font)
- Face detection status ("Face Detected" / "No Face")
- Visual indicators using icons (Font Awesome or Heroicons)

### Buttons
- Primary action: "Start Camera" / "Stop Camera" (larger, prominent)
- Secondary actions: Settings, screenshot capture
- Icon + text combination for clarity
- Consistent height: `h-10` or `h-12`
- Padding: `px-4` or `px-6`

### Dropdowns
- Camera selection dropdown (if multiple cameras available)
- Resolution/quality selector
- Clean, native-styled select elements with custom styling

### Sliders
- Overlay opacity control
- Landmark size control
- Material Design style range inputs
- Labels showing current value

### Visual Indicators
**Tracking Overlays** (on canvas):
- Face bounding box: Thin stroke outline
- Facial landmarks: Small circles at key points (eyes, nose, mouth, jawline)
- Face mesh: Connected points forming facial structure
- All overlays should have configurable opacity

### Icon System
Use **Heroicons** (outline style) via CDN for:
- Camera icon (video camera)
- Settings icon (cog/gear)
- Toggle icons (eye/eye-slash for show/hide)
- Status indicators (check-circle, x-circle)

## Layout Specifications

### Desktop Layout (lg:)
```
┌─────────────────────────────────┬──────────────┐
│                                 │   CONTROLS   │
│         VIDEO CANVAS            │              │
│      (Face Tracking Overlay)    │   Toggles    │
│                                 │   Sliders    │
│                                 │   Status     │
└─────────────────────────────────┴──────────────┘
```

### Mobile Layout
```
┌───────────────────────┐
│    VIDEO CANVAS       │
│  (Face Tracking)      │
├───────────────────────┤
│     CONTROLS          │
│   (Scrollable)        │
└───────────────────────┘
```

## Accessibility
- Clear focus states on all interactive elements
- ARIA labels for toggle switches and controls
- Keyboard navigation support for all controls
- Status announcements for screen readers (camera active/inactive, face detected)

## Animations
**Minimal and Purposeful**:
- Smooth toggle switch transitions (`transition-all duration-200`)
- Fade-in for status messages
- **No animations** on video canvas or tracking overlays (performance critical)

## Images
No hero images needed - this is a utility application. The webcam feed IS the primary visual content.

## Distinctive Features
- Professional tool aesthetic inspired by OBS, Streamlabs
- Technical precision with clear data readouts
- Control panel feels like a proper video production tool
- Clean, uncluttered interface that doesn't distract from the video feed